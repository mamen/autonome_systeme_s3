#Compile the code 
```
>>mkdir build
>>cd build
>>cmake ..
>>make
```
#Execute
```
>>./pixy_cam
```
