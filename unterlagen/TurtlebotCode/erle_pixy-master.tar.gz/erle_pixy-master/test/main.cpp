#include <iostream>
#include <string.h>
#include <stdio.h>

#include "pixycam.h"

int main(int argc, char* argv[])
{
    PixyCam cam;
    cam.run();
}
